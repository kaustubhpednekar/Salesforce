package finalday;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class TestScript {
	
	public static void main(String[] args) throws InterruptedException 
	{
		
			 ChromeOptions options = new ChromeOptions();
			 options.addArguments("--disable-notifications");
			 WebDriverManager.chromedriver().setup();
			 ChromeDriver driver = new ChromeDriver(options);
			 driver.manage().window().maximize();
			 driver.get("https://login.salesforce.com");
			 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
			 driver.findElement(By.xpath("//input[@id='username']")).sendKeys("hari.radhakrishnan@qeagle.com");
			 driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Tuna@123");
			 driver.findElement(By.xpath("//input[@id='Login']")).click();
			 
			 Thread.sleep(2000);
			//driver.findElement(By.xpath("//a[@class='switch-to-lightning']")).click();
			//Thread.sleep(2000);
			 //driver.findElement(By.xpath("//div//span/*[@class='icon noicon']")).click();
			 //driver.findElement(By.xpath("//a[text()='Switch to Salesforce Classic']")).click();
			 
			 String title = "Home | Salesforce";
			 if(driver.getTitle() == title)
			 {
				 driver.findElement(By.xpath("/html/body")).click();
				//driver.findElement(By.xpath("//div//span/*[@class='icon noicon']")).click();
				driver.findElement(By.xpath("//a[text()='Switch to Salesforce Classic']")).click();
				 
			 }
			 driver.findElement(By.xpath("//a[@title='Home Tab']")).click();
			 driver.findElement(By.id("createNewButton")).click();
			 driver.findElement(By.xpath("//a[@class='menuButtonMenuLink firstMenuItem eventMru']")).click();
			 
			 driver.findElement(By.xpath("//input[@id='lexNoThanks']")).click();
			 driver.findElement(By.xpath( "(//input[@class='btn btn-brand'])[2]")).click();

			 driver.findElement(By.xpath("//input[@id ='evt5']")).sendKeys("Call");
			 driver.findElement(By.xpath( "//input[@name='attachFile']")).click();
			 
			 Thread.sleep(1000);
			 Set<String> windowHandles = driver.getWindowHandles(); 
			 List<String> windows = new ArrayList<String>(windowHandles);
			 driver.switchTo().window(windows.get(1));
			 Thread.sleep(2000);
			 driver.findElement(By.xpath("/html/body/form[1]/div/table/tbody/tr[3]/td[2]/input")).sendKeys("C:\\Users\\XR375YG\\OneDrive - EY\\Desktop\\test.txt");
			 //driver.findElement(By.xpath("//div//table//tr[3]//td[@style=\"padding-bottom: 1em\"]//input[@id='file']")).click();
			 driver.findElement(By.xpath("/html/body/form[1]/div/table/tbody/tr[7]/td[2]/input")).click();
			 driver.findElement(By.xpath("/html/body/form[2]/table/tbody/tr[3]/td[2]/input")).click();
			 
			 driver.switchTo().window(windows.get(0));
			 driver.findElement(By.xpath("//input[@class='btn']")).click();
			 driver.findElement(By.xpath("//span[@class='mruText']")).click();
			 driver.findElement(By.xpath("//input[@name='edit']")).click();
			 WebElement build = driver.findElement(By.xpath("//input[@id='EndDateTime']"));
			 build.clear();
			 build.sendKeys("5/21/2022");
			 driver.findElement(By.xpath("//input[@name='save']")).click();
			 
			 driver.findElement(By.xpath("//span[@class='mruText']")).click();
			 driver.findElement(By.xpath("//input[@name='del']")).click();
			 
			 boolean res = driver.findElement(By.className("mruItem")).isDisplayed();
			 System.out.println(res);
			 //System.out.println(driver.getTitle());
			 
			 WebElement web = driver.findElement(By.className("mruItem"));
			System.out.println(web.getText());

			 
		
	}

}
