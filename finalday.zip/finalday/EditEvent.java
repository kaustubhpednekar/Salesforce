package finalday;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class EditEvent extends CommonClass {
	
	@Test(dependsOnMethods="finalday.NewEvent.createNew")
	public void editEvent()
	{
		 driver.findElement(By.xpath("//span[@class='mruText']")).click();
		 driver.findElement(By.xpath("//input[@name='edit']")).click();
		 driver.findElement(By.xpath("//input[@id='lexNoThanks']")).click();
		 driver.findElement(By.xpath( "(//input[@class='btn btn-brand'])[2]")).click();
		 WebElement build = driver.findElement(By.xpath("//input[@id='EndDateTime']"));
		 build.clear();
		 build.sendKeys("5/21/2022");
		 driver.findElement(By.xpath("//input[@name='save']")).click();
	}

}
