package finalday;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class DeleteEvent extends CommonClass {
	
	@Test(dependsOnMethods="finalday.EditEvent.editEvent")
	public void deleteEvent()
	{
		 
		 driver.findElement(By.xpath("//span[@class='mruText']")).click();

		 driver.findElement(By.xpath("//input[@id='lexNoThanks']")).click();
		 driver.findElement(By.xpath( "(//input[@class='btn btn-brand'])[2]")).click();
		 driver.findElement(By.xpath("//input[@name='del']")).click();
		 
		 WebElement web = driver.findElement(By.className("mruItem"));
		 System.out.println(web.getText());		 
		 
	}

}
