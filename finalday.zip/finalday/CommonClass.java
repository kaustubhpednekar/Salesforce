package finalday;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.github.bonigarcia.wdm.WebDriverManager;

public class CommonClass 
{
	public ChromeDriver driver;
	@BeforeMethod 
	public void preCondition()
	{
		ChromeOptions options = new ChromeOptions();
		 options.addArguments("--disable-notifications");
		 WebDriverManager.chromedriver().setup();
		 driver = new ChromeDriver(options);
		 driver.manage().window().maximize();
		 driver.get("https://login.salesforce.com");
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		 driver.findElement(By.xpath("//input[@id='username']")).sendKeys("hari.radhakrishnan@qeagle.com");
		 driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Tuna@123");
		 driver.findElement(By.xpath("//input[@id='Login']")).click();
		 
		 String title = "Home | Salesforce";
		 if(driver.getTitle() == title)
		 {
			 driver.findElement(By.xpath("/html/body")).click();
			//driver.findElement(By.xpath("//div//span/*[@class='icon noicon']")).click();
			driver.findElement(By.xpath("//a[text()='Switch to Salesforce Classic']")).click();
			 
		 }
		 driver.findElement(By.xpath("//a[@title='Home Tab']")).click();
	}
	
	@AfterMethod
	public void postCindition()
	{
		driver.close();
	}

}
