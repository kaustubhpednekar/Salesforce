package finalday;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.testng.annotations.Test;

public class NewEvent extends CommonClass
{
	@Test
	public void createNew() throws InterruptedException
	{
		 driver.findElement(By.id("createNewButton")).click();
		 driver.findElement(By.xpath("//a[@class='menuButtonMenuLink firstMenuItem eventMru']")).click();
		 
		 driver.findElement(By.xpath("//input[@id='lexNoThanks']")).click();
		 driver.findElement(By.xpath( "(//input[@class='btn btn-brand'])[2]")).click();

		 driver.findElement(By.xpath("//input[@id ='evt5']")).sendKeys("Manoj");
		 driver.findElement(By.xpath( "//input[@name='attachFile']")).click();
		 
		 Thread.sleep(1000);
		 Set<String> windowHandles = driver.getWindowHandles(); 
		 List<String> windows = new ArrayList<String>(windowHandles);
		 driver.switchTo().window(windows.get(1));
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("/html/body/form[1]/div/table/tbody/tr[3]/td[2]/input")).sendKeys("C:\\Users\\XR375YG\\OneDrive - EY\\Desktop\\test.txt");
		 //driver.findElement(By.xpath("//div//table//tr[3]//td[@style=\"padding-bottom: 1em\"]//input[@id='file']")).click();
		 driver.findElement(By.xpath("/html/body/form[1]/div/table/tbody/tr[7]/td[2]/input")).click();
		 driver.findElement(By.xpath("/html/body/form[2]/table/tbody/tr[3]/td[2]/input")).click();
		 
		 driver.switchTo().window(windows.get(0));
		 driver.findElement(By.xpath("//input[@class='btn']")).click();
	}

}
