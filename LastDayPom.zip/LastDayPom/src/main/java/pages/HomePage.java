package pages;

import org.openqa.selenium.By;

import hooks.BaseClass;

public class HomePage extends BaseClass
{
	public HomePage lightening() {
		 String title = "Home | Salesforce";
		 if(driver.getTitle() == title)
		 {
			 driver.findElement(By.xpath("/html/body")).click();
			//driver.findElement(By.xpath("//div//span/*[@class='icon noicon']")).click();
			driver.findElement(By.xpath("//a[text()='Switch to Salesforce Classic']")).click();
			 
		 }
		return this;
	}
	
	public Object classicview() {
	driver.findElement(By.xpath("//a[@title='Home Tab']")).click();	
		return new CreateNewEvent();
	}

	

}
