package pages;

import org.openqa.selenium.By;

import hooks.BaseClass;

public class LoginPage extends BaseClass
{
	
	public LoginPage getEmail(String userId) {
	driver.findElement(By.xpath("//input[@id='username']")).sendKeys("hari.radhakrishnan@qeagle.com");
		return this;
	}
	
	public LoginPage getPasword(String passward) {
	driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Tuna@123");	
		return this;
	}
	
	public HomePage clickLoginButton() {
	driver.findElement(By.xpath("//input[@id='Login']")).click();	
		return new HomePage();
	}	

}
