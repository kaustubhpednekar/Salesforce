package pages;

import org.openqa.selenium.By;
import hooks.BaseClass;

public class DeleteNewEvent extends BaseClass 
{
	public DeleteNewEvent homeButton()
	{
    	 driver.findElement(By.xpath("//span[@class='mruText']")).click();
		return this;
	}
	
	
	public DeleteNewEvent popUpMsg()
	{
		driver.findElement(By.xpath("//input[@id='lexNoThanks']")).click();		
		return this;
	}
	
	public DeleteNewEvent popHandle()
	{
		 driver.findElement(By.xpath( "(//input[@class='btn btn-brand'])[2]")).click();		
		return this;
	}
	
	public DeleteNewEvent delEvent()
	{
		 driver.findElement(By.xpath("//input[@name='del']")).click();
		return this; 
	}
		


}
