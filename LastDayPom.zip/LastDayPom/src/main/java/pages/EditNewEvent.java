package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import hooks.BaseClass;

public class EditNewEvent extends BaseClass
{
	public EditNewEvent homeButton()
	{
    	 driver.findElement(By.xpath("//span[@class='mruText']")).click();
		return this;
	}
	
	public EditNewEvent editEvent()
	{
		 driver.findElement(By.xpath("//input[@name='edit']")).click();
		return this;
	}
	
	public EditNewEvent popUpMsg()
	{
		driver.findElement(By.xpath("//input[@id='lexNoThanks']")).click();		
		return this;
	}
	
	public EditNewEvent popHandle()
	{
		 driver.findElement(By.xpath( "(//input[@class='btn btn-brand'])[2]")).click();		
		return this;
	}
		
	
	public EditNewEvent changeDate()
	{	
		 WebElement build = driver.findElement(By.xpath("//input[@id='EndDateTime']"));
		 build.clear();
		 build.sendKeys("5/21/2022");
		return this;
	}
	
	public EditNewEvent saveEvent()
	{
		driver.findElement(By.xpath("//input[@class='btn']")).click();
		return this;
	}	
	

}
