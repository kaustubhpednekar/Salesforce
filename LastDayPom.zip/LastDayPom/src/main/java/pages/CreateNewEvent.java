package pages;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;

import hooks.BaseClass;

public class CreateNewEvent extends BaseClass
{
	public CreateNewEvent createNew()
	{
		driver.findElement(By.id("createNewButton")).click();
		return this;
	}
	
	public CreateNewEvent eventNew()
	{
		driver.findElement(By.xpath("//a[@class='menuButtonMenuLink firstMenuItem eventMru']")).click();
		return this;
	}
	
	public CreateNewEvent popUpMsg()
	{
		driver.findElement(By.xpath("//input[@id='lexNoThanks']")).click();		
		return this;
	}
	
	public CreateNewEvent popHandle()
	{
		 driver.findElement(By.xpath( "(//input[@class='btn btn-brand'])[2]")).click();		
		return this;
	}
	
	public CreateNewEvent subName(String name)
	{
		 driver.findElement(By.xpath("//input[@id ='evt5']")).sendKeys("Manoj");		
		return this;
	}
	
	public CreateNewEvent attachFile() throws InterruptedException
	{
		 driver.findElement(By.xpath( "//input[@name='attachFile']")).click();
		 Thread.sleep(1000);
		return this;
	}
	
	public CreateNewEvent windowHandle() throws InterruptedException
	{
		 Set<String> windowHandles = driver.getWindowHandles(); 
		 List<String> windows = new ArrayList<String>(windowHandles);
		 driver.switchTo().window(windows.get(1));
		 Thread.sleep(2000);		
	
		driver.findElement(By.xpath("/html/body/form[1]/div/table/tbody/tr[3]/td[2]/input")).sendKeys("C:\\Users\\XR375YG\\OneDrive - EY\\Desktop\\test.txt");			

		 driver.findElement(By.xpath("/html/body/form[1]/div/table/tbody/tr[7]/td[2]/input")).click();		

		 driver.findElement(By.xpath("/html/body/form[2]/table/tbody/tr[3]/td[2]/input")).click();		

		 Thread.sleep(2000);
		 driver.switchTo().window(windows.get(0));
		 Thread.sleep(3000);
		 driver.findElement(By.xpath("//input[@class='btn']")).click();		
		return this;
	}
	
	public CreateNewEvent saveEvent()
	{
		driver.findElement(By.xpath("//input[@class='btn']")).click();
		return this;
	}


}
