package testcases;

import org.testng.annotations.Test;

import hooks.BaseClass;
import pages.EditNewEvent;
import pages.HomePage;
import pages.LoginPage;

public class TestCaseForEdit extends BaseClass
{
	   @Test
		public void testCases() throws InterruptedException 
	   {
		   LoginPage login =new LoginPage();
		   login.getEmail("hari.radhakrishnan@qeagle.com");
		   login.getPasword("Tuna@123");
		   login.clickLoginButton();
		   
		   Thread.sleep(1000);
		   HomePage home =new HomePage();
		   home.lightening();
		   home.classicview();
		   
		   Thread.sleep(1000);
           EditNewEvent edit =new EditNewEvent();
		   edit.homeButton().editEvent().popUpMsg();
		   edit.popHandle();
		   Thread.sleep(3000);
		   edit.changeDate().saveEvent();
	   }	

}
