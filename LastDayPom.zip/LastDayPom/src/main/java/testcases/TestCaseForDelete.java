package testcases;

import org.testng.annotations.Test;

import hooks.BaseClass;
import pages.DeleteNewEvent;
import pages.HomePage;
import pages.LoginPage;

public class TestCaseForDelete extends BaseClass
{

	   @Test
		public void testCases() throws InterruptedException 
	   {
		   LoginPage login =new LoginPage();
		   login.getEmail("hari.radhakrishnan@qeagle.com");
		   login.getPasword("Tuna@123");
		   login.clickLoginButton();
		   
		   Thread.sleep(1000);
		   HomePage home =new HomePage();
		   home.lightening();
		   home.classicview();
		   
		   Thread.sleep(1000);
		   DeleteNewEvent del = new DeleteNewEvent();
		   del.homeButton().popUpMsg().popHandle().delEvent();
		   
	   }
			

}
