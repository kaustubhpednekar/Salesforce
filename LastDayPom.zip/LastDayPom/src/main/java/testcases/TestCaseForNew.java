package testcases;

import org.testng.annotations.Test;

import hooks.BaseClass;
import pages.CreateNewEvent;
import pages.HomePage;
import pages.LoginPage;



public class TestCaseForNew extends BaseClass
{
	/*
	 * @BeforeTest public void initialize() throws IOException {
	 * 
	 * driver = initializeDriver(); }
	 */	


	   @Test
		public void testCases() throws InterruptedException 
	   {
		   LoginPage login =new LoginPage();
		   login.getEmail("hari.radhakrishnan@qeagle.com");
		   login.getPasword("Tuna@123");
		   login.clickLoginButton();
		   
		   Thread.sleep(1000);
		   HomePage home =new HomePage();
		   home.lightening();
		   home.classicview();
		   
		   Thread.sleep(1000);
		   CreateNewEvent create =new CreateNewEvent();
		   create.createNew().eventNew().popUpMsg().popHandle();
		   create.subName("Manoj").attachFile().windowHandle();
		   
	   }

}
